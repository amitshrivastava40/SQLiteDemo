//
//  ViewController.swift
//  sqlite_demo
//
//  Created by Mac on 29/08/18.
//  Copyright © 2018 Mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var arr = [Any]();
    
    var id:Int? ;
    
    
    
    @IBOutlet weak var insert: UIButton!
    
    @IBOutlet weak var tbl: UITableView!
    
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtempadd: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getdata();
        
        insert.tag = 1;
        
        
   }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arr.count;
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let temp = arr[indexPath.section] as! [String]
        print(temp)
        if indexPath.row == 0 {
            cell.textLabel?.text = temp[0];
        }
        if indexPath.row == 1 {
            cell.textLabel?.text = temp[1];
        }
        if indexPath.row == 2 {
            cell.textLabel?.text = temp[2];
        }
        return cell;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let temp = arr[indexPath.section] as! [String]
     
        id = Int(temp[0])
        txtempname.text = temp[1]
        txtempadd.text = temp[2]
        
    
        insert.tag = 2
        insert.setTitle("Update", for: .normal);
        
        
    }
    
    
    @IBAction func buttonclick(_ sender: Any) {
        
        if insert.tag == 1
        {
        
        let strquery = "insert into tblemp(emp_name,emp_add)values('\(txtempname.text!)','\(txtempadd.text!)')";
        
        let obj = common();
        var op = obj.dml(str: strquery);
        
        if op == true {
            print("Success");
            getdata();
        }
        else{
            print("not success");
        }
        }
        
        if insert.tag == 2{
            insert.tag = 1
            insert.setTitle("Insert", for: .normal);
            
        }

    }
    
    func getdata()  {
        let obj = common();
        arr = obj.getdata(str: "select *from tblemp");
        print(arr);
        tbl.reloadData();
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

