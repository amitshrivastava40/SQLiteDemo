//
//  sqlite_demo-Bridging-Header.h
//  sqlite_demo
//
//  Created by Mac on 29/08/18.
//  Copyright © 2018 Mac. All rights reserved.
//

#ifndef sqlite_demo_Bridging_Header_h
#define sqlite_demo_Bridging_Header_h
#import<sqlite3.h>


#endif /* sqlite_demo_Bridging_Header_h */
